var searchData=
[
  ['start_0',['start',['../class_g_u_i.html#a90699c69fd341d7ea1f31a580103a155',1,'GUI']]]
];
